# Mapa IA

Editor web para transformar imagens de mapas em territórios SVG editáveis.

## Arquivos principais

- `src/routes/index.tsx` — interface e editor.
- `src/lib/detect.ts` — detecção e vetorização dos territórios.
- `src/styles.css` — tema visual.
- `package.json` — dependências.

## Recursos

- PNG/JPG/WebP
- detecção por cor
- detecção por linhas escuras
- edição de nome e cores
- ocultar/excluir territórios
- polígono manual
- zoom e pan
- undo/redo
- exportação SVG, PNG e JSON
- importação JSON

A detecção é feita localmente no navegador e pode exigir correções manuais.
