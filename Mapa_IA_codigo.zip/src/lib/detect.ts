export type Territory = {
  id: string;
  name: string;
  color: string;
  stroke: string;
  strokeWidth: number;
  visible: boolean;
  d: string;
};

export type DetectOptions = {
  mode: "color" | "lines";
  tolerance: number;
  levels: number;
  minArea: number;
  epsilon: number;
  ignoreBackground: boolean;
  darkThreshold: number;
};

type Pt = [number, number];

function rdp(pts: Pt[], eps: number): Pt[] {
  if (pts.length < 3) return pts;
  const [ax, ay] = pts[0];
  const [bx, by] = pts[pts.length - 1];
  const dx = bx - ax, dy = by - ay;
  const len = Math.hypot(dx, dy) || 1;
  let max = 0, idx = 0;
  for (let i = 1; i < pts.length - 1; i++) {
    const [px, py] = pts[i];
    const d = Math.abs(dy * px - dx * py + bx * ay - by * ax) / len;
    if (d > max) { max = d; idx = i; }
  }
  if (max > eps) {
    const a = rdp(pts.slice(0, idx + 1), eps);
    const b = rdp(pts.slice(idx), eps);
    return a.slice(0, -1).concat(b);
  }
  return [pts[0], pts[pts.length - 1]];
}

function simplifyLoop(loop: Pt[], eps: number): Pt[] {
  if (loop.length < 8) return loop;
  let far = 0, fd = 0;
  for (let i = 1; i < loop.length; i++) {
    const d = Math.hypot(loop[i][0] - loop[0][0], loop[i][1] - loop[0][1]);
    if (d > fd) { fd = d; far = i; }
  }
  const a = rdp(loop.slice(0, far + 1), eps);
  const b = rdp(loop.slice(far).concat([loop[0]]), eps);
  return a.slice(0, -1).concat(b.slice(0, -1));
}

function traceLoops(labels: Int32Array, w: number, h: number, label: number, x0: number, y0: number, x1: number, y1: number): Pt[][] {
  const W = w + 1;
  const next = new Map<number, number[]>();
  const add = (ax: number, ay: number, bx: number, by: number) => {
    const k = ay * W + ax, v = by * W + bx;
    const arr = next.get(k);
    if (arr) arr.push(v); else next.set(k, [v]);
  };
  const inside = (x: number, y: number) => x >= 0 && y >= 0 && x < w && y < h && labels[y * w + x] === label;
  for (let y = y0; y <= y1; y++) for (let x = x0; x <= x1; x++) {
    if (labels[y * w + x] !== label) continue;
    if (!inside(x, y - 1)) add(x, y, x + 1, y);
    if (!inside(x + 1, y)) add(x + 1, y, x + 1, y + 1);
    if (!inside(x, y + 1)) add(x + 1, y + 1, x, y + 1);
    if (!inside(x - 1, y)) add(x, y + 1, x, y);
  }
  const loops: Pt[][] = [];
  for (const [start] of next) {
    let arr = next.get(start);
    if (!arr || !arr.length) continue;
    const loop: Pt[] = [];
    let cur = start, guard = 0;
    while (guard++ < 1e7) {
      arr = next.get(cur);
      if (!arr || !arr.length) break;
      const nx = arr.pop()!;
      loop.push([cur % W, Math.floor(cur / W)]);
      cur = nx;
      if (cur === start) break;
    }
    if (loop.length >= 4) loops.push(loop);
  }
  return loops;
}

const hex = (r: number, g: number, b: number) => "#" + [r, g, b].map((v) => Math.round(v).toString(16).padStart(2, "0")).join("");

export function detect(img: HTMLImageElement, opts: DetectOptions, onProgress?: (p: number) => void): Territory[] {
  const ow = img.naturalWidth, oh = img.naturalHeight;
  const scale = Math.min(1, 700 / Math.max(ow, oh));
  const w = Math.max(1, Math.round(ow * scale)), h = Math.max(1, Math.round(oh * scale));
  const c = document.createElement("canvas");
  c.width = w; c.height = h;
  const ctx = c.getContext("2d", { willReadFrequently: true })!;
  ctx.drawImage(img, 0, 0, w, h);
  const data = ctx.getImageData(0, 0, w, h).data;
  const n = w * h;
  const q = new Uint8ClampedArray(n * 3);
  const step = 256 / opts.levels;
  const wall = new Uint8Array(n);
  for (let i = 0; i < n; i++) {
    const r = data[i * 4], g = data[i * 4 + 1], b = data[i * 4 + 2], a = data[i * 4 + 3];
    q[i * 3] = Math.floor(r / step) * step + step / 2;
    q[i * 3 + 1] = Math.floor(g / step) * step + step / 2;
    q[i * 3 + 2] = Math.floor(b / step) * step + step / 2;
    const lum = 0.299 * r + 0.587 * g + 0.114 * b;
    if (a < 20 || lum < opts.darkThreshold) wall[i] = 1;
  }
  const labels = new Int32Array(n).fill(-1);
  const tol2 = Math.pow((opts.tolerance / 100) * 441, 2);
  const stack = new Int32Array(n);
  type Comp = { label: number; area: number; r: number; g: number; b: number; x0: number; y0: number; x1: number; y1: number; edge: boolean };
  const comps: Comp[] = [];
  let label = 0;
  for (let s = 0; s < n; s++) {
    if (labels[s] !== -1) continue;
    if (wall[s]) { labels[s] = -2; continue; }
    const sr = q[s * 3], sg = q[s * 3 + 1], sb = q[s * 3 + 2];
    let sp = 0; stack[sp++] = s; labels[s] = label;
    const cp: Comp = { label, area: 0, r: 0, g: 0, b: 0, x0: w, y0: h, x1: 0, y1: 0, edge: false };
    while (sp) {
      const i = stack[--sp], x = i % w, y = (i / w) | 0;
      cp.area++; cp.r += data[i * 4]; cp.g += data[i * 4 + 1]; cp.b += data[i * 4 + 2];
      if (x < cp.x0) cp.x0 = x; if (x > cp.x1) cp.x1 = x; if (y < cp.y0) cp.y0 = y; if (y > cp.y1) cp.y1 = y;
      if (x === 0 || y === 0 || x === w - 1 || y === h - 1) cp.edge = true;
      const nb = [x > 0 ? i - 1 : -1, x < w - 1 ? i + 1 : -1, y > 0 ? i - w : -1, y < h - 1 ? i + w : -1];
      for (const j of nb) {
        if (j < 0 || labels[j] !== -1 || wall[j]) continue;
        if (opts.mode === "color") {
          const dr = q[j * 3] - sr, dg = q[j * 3 + 1] - sg, db = q[j * 3 + 2] - sb;
          if (dr * dr + dg * dg + db * db > tol2) continue;
        }
        labels[j] = label; stack[sp++] = j;
      }
    }
    comps.push(cp); label++;
  }
  onProgress?.(0.5);
  const minPx = Math.max(12, opts.minArea * n);
  let valid = comps.filter((c) => c.area >= minPx);
  if (opts.ignoreBackground) {
    const edgeComps = valid.filter((c) => c.edge).sort((a, b) => b.area - a.area);
    if (edgeComps[0]) valid = valid.filter((c) => c !== edgeComps[0]);
  }
  const inv = 1 / scale;
  const out: Territory[] = [];
  valid.forEach((cp, idx) => {
    const loops = traceLoops(labels, w, h, cp.label, cp.x0, cp.y0, cp.x1, cp.y1);
    let d = "";
    for (const lp of loops) {
      const s = simplifyLoop(lp, opts.epsilon);
      if (s.length < 3) continue;
      d += "M" + s.map(([x, y]) => `${(x * inv).toFixed(1)} ${(y * inv).toFixed(1)}`).join("L") + "Z";
    }
    if (!d) return;
    out.push({
      id: "t" + Date.now().toString(36) + idx,
      name: `Território ${out.length + 1}`,
      color: opts.mode === "color" ? hex(cp.r / cp.area, cp.g / cp.area, cp.b / cp.area) : `hsl(${(idx * 47) % 360} 60% 55%)`,
      stroke: "#111827",
      strokeWidth: 1.5,
      visible: true,
      d,
    });
  });
  onProgress?.(1);
  return out;
}

export function makeDemoMap(): string {
  const w = 900, h = 600;
  const c = document.createElement("canvas");
  c.width = w; c.height = h;
  const ctx = c.getContext("2d")!;
  const img = ctx.createImageData(w, h);
  let seed = 7;
  const rnd = () => ((seed = (seed * 16807) % 2147483647) / 2147483647);
  const seeds = Array.from({ length: 11 }, () => [150 + rnd() * 600, 120 + rnd() * 360]);
  const pal = [[214, 170, 110], [142, 186, 120], [200, 130, 120], [230, 205, 130], [150, 160, 200], [120, 170, 160], [210, 160, 190], [180, 200, 110], [230, 150, 90], [160, 130, 180], [190, 190, 160]];
  const own = new Int16Array(w * h);
  for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) {
    const nx = (x - 450) / 360, ny = (y - 300) / 240;
    const r = Math.sqrt(nx * nx + ny * ny) + 0.12 * Math.sin(x / 37) * Math.cos(y / 29) + 0.06 * Math.sin(x / 13 + y / 17);
    let k = -1;
    if (r < 1) { let bd = 1e9; seeds.forEach(([sx, sy], i) => { const d = (x - sx) ** 2 + (y - sy) ** 2; if (d < bd) { bd = d; k = i; } }); }
    own[y * w + x] = k;
  }
  for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) {
    const i = y * w + x, k = own[i];
    let border = false;
    for (let dy = -1; dy <= 1 && !border; dy++) for (let dx = -1; dx <= 1; dx++) {
      const xx = x + dx, yy = y + dy;
      if (xx >= 0 && yy >= 0 && xx < w && yy < h && own[yy * w + xx] !== k) { border = true; break; }
    }
    const col = border ? [30, 30, 35] : k < 0 ? [70, 120, 170] : pal[k];
    img.data.set([col[0], col[1], col[2], 255], i * 4);
  }
  ctx.putImageData(img, 0, 0);
  return c.toDataURL("image/png");
}