import { createFileRoute } from "@tanstack/react-router";
import { useCallback, useEffect, useRef, useState } from "react";
import { Upload, Wand2, Undo2, Redo2, Eye, EyeOff, PenTool, Download, FileJson, Image as ImageIcon, Map as MapIcon, Trash2, Check, X, Maximize } from "lucide-react";
import { detect, makeDemoMap, type Territory, type DetectOptions } from "@/lib/detect";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Mapa IA — imagens de mapas em vetores editáveis" },
      { name: "description", content: "Transforme imagens de mapas fictícios em mapas SVG editáveis, direto no navegador." },
      { property: "og:title", content: "Mapa IA" },
      { property: "og:description", content: "Detecte territórios e exporte SVG, PNG e JSON localmente." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: App,
});

type Doc = { width: number; height: number; territories: Territory[] };
const btn = "inline-flex min-h-11 items-center justify-center gap-2 rounded-lg px-3 text-sm font-medium transition active:scale-95 disabled:opacity-40";
const pri = `${btn} bg-primary text-primary-foreground`;
const sec = `${btn} bg-secondary text-secondary-foreground border border-border`;

function App() {
  const [src, setSrc] = useState<string | null>(null);
  const [doc, setDoc] = useState<Doc>({ width: 900, height: 600, territories: [] });
  const [past, setPast] = useState<Territory[][]>([]);
  const [future, setFuture] = useState<Territory[][]>([]);
  const [sel, setSel] = useState<string | null>(null);
  const [showRaster, setShowRaster] = useState(true);
  const [query, setQuery] = useState("");
  const [busy, setBusy] = useState(false);
  const [poly, setPoly] = useState<[number, number][] | null>(null);
  const [opts, setOpts] = useState<DetectOptions>({ mode: "color", tolerance: 12, levels: 8, minArea: 0.002, epsilon: 1.2, ignoreBackground: true, darkThreshold: 60 });
  const [view, setView] = useState({ x: 0, y: 0, k: 1 });
  const imgRef = useRef<HTMLImageElement | null>(null);
  const boxRef = useRef<HTMLDivElement>(null);
  const svgRef = useRef<SVGSVGElement>(null);

  const commit = (t: Territory[]) => { setPast((p) => [...p.slice(-50), doc.territories]); setFuture([]); setDoc((d) => ({ ...d, territories: t })); };
  const undo = () => { if (!past.length) return; setFuture((f) => [doc.territories, ...f]); setDoc((d) => ({ ...d, territories: past[past.length - 1] })); setPast((p) => p.slice(0, -1)); };
  const redo = () => { if (!future.length) return; setPast((p) => [...p, doc.territories]); setDoc((d) => ({ ...d, territories: future[0] })); setFuture((f) => f.slice(1)); };

  const fit = useCallback((w: number, h: number) => {
    const el = boxRef.current; if (!el) return;
    const k = Math.min(el.clientWidth / w, el.clientHeight / h) * 0.95;
    setView({ k, x: (el.clientWidth - w * k) / 2, y: (el.clientHeight - h * k) / 2 });
  }, []);

  const loadSrc = (url: string) => {
    const img = new Image();
    img.onload = () => { imgRef.current = img; setSrc(url); setDoc({ width: img.naturalWidth, height: img.naturalHeight, territories: [] }); setPast([]); setFuture([]); setSel(null); fit(img.naturalWidth, img.naturalHeight); };
    img.src = url;
  };
  useEffect(() => { loadSrc(makeDemoMap()); }, []); // eslint-disable-line

  const runDetect = () => {
    if (!imgRef.current) return;
    setBusy(true);
    setTimeout(() => { try { commit(detect(imgRef.current!, opts)); } finally { setBusy(false); } }, 30);
  };

  const pointers = useRef(new Map<number, { x: number; y: number }>());
  const last = useRef<{ x: number; y: number; d: number } | null>(null);
  const moved = useRef(false);
  const toImg = (cx: number, cy: number) => { const r = boxRef.current!.getBoundingClientRect(); return [(cx - r.left - view.x) / view.k, (cy - r.top - view.y) / view.k] as [number, number]; };
  const zoomAt = (px: number, py: number, f: number) => setView((v) => { const k = Math.min(40, Math.max(0.05, v.k * f)); const s = k / v.k; return { k, x: px - (px - v.x) * s, y: py - (py - v.y) * s }; });
  useEffect(() => {
    const el = boxRef.current; if (!el) return;
    const onWheel = (e: WheelEvent) => { e.preventDefault(); const r = el.getBoundingClientRect(); const dy = e.deltaY * (e.deltaMode === 1 ? 16 : 1); zoomAt(e.clientX - r.left, e.clientY - r.top, Math.exp(-dy * 0.0015)); };
    el.addEventListener("wheel", onWheel, { passive: false });
    return () => el.removeEventListener("wheel", onWheel);
  }, []);
  const state = () => { const ps = [...pointers.current.values()]; const x = ps.reduce((a, p) => a + p.x, 0) / ps.length, y = ps.reduce((a, p) => a + p.y, 0) / ps.length; const d = ps.length > 1 ? Math.hypot(ps[0].x - ps[1].x, ps[0].y - ps[1].y) : 0; return { x, y, d }; };
  const onDown = (e: React.PointerEvent) => { (e.currentTarget as HTMLElement).setPointerCapture(e.pointerId); pointers.current.set(e.pointerId, { x: e.clientX, y: e.clientY }); last.current = state(); moved.current = false; };
  const onMove = (e: React.PointerEvent) => {
    if (!pointers.current.has(e.pointerId)) return;
    pointers.current.set(e.pointerId, { x: e.clientX, y: e.clientY });
    const s = state(), l = last.current; if (!l) return;
    if (Math.hypot(s.x - l.x, s.y - l.y) > 3 || (s.d && Math.abs(s.d - l.d) > 3)) moved.current = true;
    const r = boxRef.current!.getBoundingClientRect();
    setView((v) => { let { x, y, k } = v; x += s.x - l.x; y += s.y - l.y; if (s.d && l.d) { const nk = Math.min(40, Math.max(0.05, k * s.d / l.d)); const px = s.x - r.left, py = s.y - r.top; x = px - (px - x) * (nk / k); y = py - (py - y) * (nk / k); k = nk; } return { x, y, k }; });
    last.current = s;
  };
  const onUp = (e: React.PointerEvent) => {
    pointers.current.delete(e.pointerId); last.current = pointers.current.size ? state() : null;
    if (!moved.current && pointers.current.size === 0) {
      if (poly) { setPoly([...poly, toImg(e.clientX, e.clientY)]); return; }
      const id = (document.elementFromPoint(e.clientX, e.clientY) as Element | null)?.getAttribute("data-territory-id");
      setSel(id ?? null);
    }
  };

  const finishPoly = () => {
    if (poly && poly.length >= 3) {
      const t: Territory = { id: "m" + Date.now().toString(36), name: `Território ${doc.territories.length + 1}`, color: "#f59e0b", stroke: "#111827", strokeWidth: 1.5, visible: true, d: "M" + poly.map(([x, y]) => `${x.toFixed(1)} ${y.toFixed(1)}`).join("L") + "Z" };
      commit([...doc.territories, t]); setSel(t.id);
    }
    setPoly(null);
  };

  const selected = doc.territories.find((t) => t.id === sel);
  const update = (patch: Partial<Territory>) => selected && commit(doc.territories.map((t) => (t.id === sel ? { ...t, ...patch } : t)));

  const esc = (s: string) => s.replace(/[&<>"]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" })[c]!);
  const buildSvg = () => `<svg xmlns="http://www.w3.org/2000/svg" width="${doc.width}" height="${doc.height}" viewBox="0 0 ${doc.width} ${doc.height}">\n${doc.territories.filter((t) => t.visible).map((t) => `  <path data-territory-id="${t.id}" data-name="${esc(t.name)}" d="${t.d}" fill="${t.color}" stroke="${t.stroke}" stroke-width="${t.strokeWidth}" fill-rule="evenodd"><title>${esc(t.name)}</title></path>`).join("\n")}\n</svg>`;
  const download = (blob: Blob, name: string) => { const a = document.createElement("a"); a.href = URL.createObjectURL(blob); a.download = name; a.click(); setTimeout(() => URL.revokeObjectURL(a.href), 2000); };
  const exportPng = () => {
    const img = new Image(); const url = URL.createObjectURL(new Blob([buildSvg()], { type: "image/svg+xml" }));
    img.onload = () => { const c = document.createElement("canvas"); c.width = doc.width; c.height = doc.height; c.getContext("2d")!.drawImage(img, 0, 0); c.toBlob((b) => b && download(b, "mapa.png")); URL.revokeObjectURL(url); };
    img.src = url;
  };
  const importJson = (f: File) => f.text().then((s) => { try { const j = JSON.parse(s) as Doc; if (!Array.isArray(j.territories)) throw 0; setPast((p) => [...p, doc.territories]); setDoc({ width: j.width, height: j.height, territories: j.territories }); fit(j.width, j.height); } catch { alert("JSON inválido"); } });

  const list = doc.territories.filter((t) => t.name.toLowerCase().includes(query.toLowerCase()));

  return (
    <div className="flex h-[100dvh] flex-col bg-background text-foreground lg:flex-row">
      <aside className="order-2 max-h-[48dvh] overflow-y-auto border-t border-border bg-card p-3 lg:order-1 lg:max-h-none lg:w-96 lg:border-r lg:border-t-0">
        <div className="mb-3 flex items-center gap-2"><MapIcon className="h-6 w-6 text-primary" /><h1 className="text-xl font-bold">Mapa IA</h1></div>
        <div className="grid grid-cols-2 gap-2">
          <label className={sec}><Upload className="h-4 w-4" />Imagem<input type="file" accept="image/png,image/jpeg,image/webp" className="hidden" onChange={(e) => { const f = e.target.files?.[0]; if (f) loadSrc(URL.createObjectURL(f)); e.target.value = ""; }} /></label>
          <button className={sec} onClick={() => loadSrc(makeDemoMap())}><MapIcon className="h-4 w-4" />Demo</button>
          <button className={`${pri} col-span-2`} disabled={!src || busy} onClick={runDetect}><Wand2 className="h-4 w-4" />{busy ? "Processando…" : "Detectar territórios"}</button>
        </div>
        <p className="mt-2 rounded-lg border border-accent/40 bg-accent/10 p-2 text-xs text-accent">A detecção automática é aproximada e pode precisar de correção manual.</p>
        <details className="mt-2 rounded-lg border border-border p-2 text-sm">
          <summary className="cursor-pointer py-1 font-medium">Ajustes de detecção</summary>
          <div className="mt-2 space-y-2">
            <div className="grid grid-cols-2 gap-2">
              {(["color", "lines"] as const).map((m) => <button key={m} className={opts.mode === m ? pri : sec} onClick={() => setOpts({ ...opts, mode: m })}>{m === "color" ? "Por cor" : "Linhas escuras"}</button>)}
            </div>
            {([["tolerance", "Tolerância", 0, 60, 1], ["levels", "Níveis de cor", 2, 32, 1], ["darkThreshold", "Limite de linha escura", 0, 200, 1], ["epsilon", "Simplificação", 0.3, 5, 0.1], ["minArea", "Área mínima", 0.0002, 0.02, 0.0002]] as const).map(([k, l, a, b, s]) => (
              <label key={k} className="block text-xs text-muted-foreground">{l}: {String(opts[k])}<input type="range" min={a} max={b} step={s} value={opts[k] as number} onChange={(e) => setOpts({ ...opts, [k]: +e.target.value })} className="h-8 w-full accent-primary" /></label>
            ))}
            <label className="flex min-h-11 items-center gap-2"><input type="checkbox" className="h-5 w-5 accent-primary" checked={opts.ignoreBackground} onChange={(e) => setOpts({ ...opts, ignoreBackground: e.target.checked })} />Ignorar fundo (oceano)</label>
          </div>
        </details>

        {selected && (
          <div className="mt-3 space-y-2 rounded-lg border border-primary/50 p-3">
            <input className="min-h-11 w-full rounded-lg border border-input bg-background px-3" value={selected.name} onChange={(e) => setDoc((d) => ({ ...d, territories: d.territories.map((t) => (t.id === sel ? { ...t, name: e.target.value } : t)) }))} onFocus={() => setPast((p) => [...p, doc.territories])} />
            <div className="flex items-center gap-3 text-sm">
              <label className="flex items-center gap-1">Cor<input type="color" className="h-10 w-12" value={selected.color.startsWith("#") ? selected.color : "#888888"} onChange={(e) => update({ color: e.target.value })} /></label>
              <label className="flex items-center gap-1">Borda<input type="color" className="h-10 w-12" value={selected.stroke} onChange={(e) => update({ stroke: e.target.value })} /></label>
              <input type="number" min={0} max={20} step={0.5} className="min-h-10 w-16 rounded border border-input bg-background px-2" value={selected.strokeWidth} onChange={(e) => update({ strokeWidth: +e.target.value })} />
            </div>
            <div className="grid grid-cols-2 gap-2">
              <button className={sec} onClick={() => update({ visible: !selected.visible })}>{selected.visible ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}{selected.visible ? "Ocultar" : "Mostrar"}</button>
              <button className={`${btn} bg-destructive text-destructive-foreground`} onClick={() => { commit(doc.territories.filter((t) => t.id !== sel)); setSel(null); }}><Trash2 className="h-4 w-4" />Excluir</button>
            </div>
          </div>
        )}

        <input placeholder={`Buscar entre ${doc.territories.length} territórios…`} className="mt-3 min-h-11 w-full rounded-lg border border-input bg-background px-3" value={query} onChange={(e) => setQuery(e.target.value)} />
        <ul className="mt-2 space-y-1">
          {list.map((t) => (
            <li key={t.id} className={`flex min-h-11 items-center gap-2 rounded-lg px-2 ${t.id === sel ? "bg-secondary" : ""}`}>
              <button className="flex flex-1 items-center gap-2 text-left text-sm" onClick={() => setSel(t.id)}><span className="h-5 w-5 shrink-0 rounded border border-border" style={{ background: t.color }} /><span className="truncate">{t.name}</span></button>
              <button aria-label="Visibilidade" className="p-2" onClick={() => commit(doc.territories.map((x) => (x.id === t.id ? { ...x, visible: !x.visible } : x)))}>{t.visible ? <Eye className="h-4 w-4" /> : <EyeOff className="h-4 w-4 text-muted-foreground" />}</button>
            </li>
          ))}
        </ul>
      </aside>

      <main className="relative order-1 flex min-h-0 flex-1 flex-col lg:order-2">
        <div className="flex gap-2 overflow-x-auto border-b border-border bg-card p-2">
          <button className={sec} aria-label="Desfazer" disabled={!past.length} onClick={undo}><Undo2 className="h-5 w-5" /></button>
          <button className={sec} aria-label="Refazer" disabled={!future.length} onClick={redo}><Redo2 className="h-5 w-5" /></button>
          <button className={showRaster ? pri : sec} onClick={() => setShowRaster(!showRaster)}><ImageIcon className="h-4 w-4" />Fonte</button>
          {poly ? (<><button className={pri} onClick={finishPoly}><Check className="h-4 w-4" />Concluir ({poly.length})</button><button className={sec} onClick={() => setPoly(null)}><X className="h-4 w-4" /></button></>) : <button className={sec} onClick={() => { setPoly([]); setSel(null); }}><PenTool className="h-4 w-4" />Polígono</button>}
          <button className={sec} aria-label="Ajustar" onClick={() => fit(doc.width, doc.height)}><Maximize className="h-4 w-4" /></button>
          <button className={sec} onClick={() => download(new Blob([buildSvg()], { type: "image/svg+xml" }), "mapa.svg")}><Download className="h-4 w-4" />SVG</button>
          <button className={sec} onClick={exportPng}><Download className="h-4 w-4" />PNG</button>
          <button className={sec} onClick={() => download(new Blob([JSON.stringify(doc, null, 2)], { type: "application/json" }), "mapa.json")}><FileJson className="h-4 w-4" />JSON</button>
          <label className={sec}><FileJson className="h-4 w-4" />Importar<input type="file" accept="application/json,.json" className="hidden" onChange={(e) => { const f = e.target.files?.[0]; if (f) importJson(f); e.target.value = ""; }} /></label>
        </div>
        <div ref={boxRef} className="relative flex-1 touch-none overflow-hidden bg-muted" onPointerDown={onDown} onPointerMove={onMove} onPointerUp={onUp} onPointerCancel={onUp}>
          <svg ref={svgRef} className="absolute left-0 top-0 overflow-visible" width={doc.width} height={doc.height} style={{ transform: `translate(${view.x}px,${view.y}px) scale(${view.k})`, transformOrigin: "0 0" }}>
            {showRaster && src && <image href={src} width={doc.width} height={doc.height} opacity={doc.territories.length ? 0.35 : 1} style={{ pointerEvents: "none" }} />}
            {doc.territories.filter((t) => t.visible).map((t) => (
              <path key={t.id} data-territory-id={t.id} d={t.d} fill={t.color} fillRule="evenodd" stroke={t.id === sel ? "#5eead4" : t.stroke} strokeWidth={(t.id === sel ? 3 : t.strokeWidth) / Math.max(view.k, 0.3)} fillOpacity={showRaster ? 0.75 : 1} />
            ))}
            {poly && poly.length > 0 && <><polyline points={poly.map((p) => p.join(",")).join(" ")} fill="rgba(245,158,11,0.3)" stroke="#f59e0b" strokeWidth={2 / view.k} />{poly.map(([x, y], i) => <circle key={i} cx={x} cy={y} r={5 / view.k} fill="#f59e0b" />)}</>}
          </svg>
          {poly && <div className="pointer-events-none absolute left-2 top-2 rounded-lg bg-card/90 px-3 py-2 text-xs">Toque para adicionar pontos</div>}
        </div>
      </main>
    </div>
  );
}